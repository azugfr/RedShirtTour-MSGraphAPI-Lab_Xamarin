<#
.SYNOPSIS
    After tenant has been created and admin account manually set up, 
    using  Azure Active Directory PowerShell for Graph module, launch this script.
    Login/password of tenant admin will be prompted.
    Export of accounts password will be stored in a CSV file 
.DESCRIPTION
    Done for Azure Red Shirt Tour Paris 2018
.LINK
     https://docs.microsoft.com/en-us/powershell/module/azuread/?view=azureadps-2.0
#>
param(
    [string]$createdAccountCSVExportFullPath)

#Connect to service
$UserCredential = Get-Credential
Connect-AzureAD -Credential $UserCredential 

#get tenant info
$tenantInfo = Get-AzureADTenantDetail
$tenantDomain = $tenantInfo.VerifiedDomains[0].Name
$accountSku = Get-AzureADSubscribedSku | Where-Object {$_.SkuPartNumber -eq 'ENTERPRISEPACK'}

#create users and attrib licence
$userList = 1..21 | % {"{0:D3}" -f $_}  | % {
    $PasswordProfile = New-Object -TypeName Microsoft.Open.AzureAD.Model.PasswordProfile
    $PasswordProfile.EnforceChangePasswordPolicy = $true
    $PasswordProfile.Password = "3Rv0y1q39!$_"
    New-AzureADUser -DisplayName "Attendee $_" -GivenName "$_" -SurName "Test" -UserPrincipalName "attendee$_@$tenantDomain" -MailNickName "Attendee$_" -UsageLocation FR -PasswordProfile $PasswordProfile -AccountEnabled $true
}

$License = New-Object -TypeName Microsoft.Open.AzureAD.Model.AssignedLicense
$License.SkuId = $accountSku.SkuId
$AssignedLicenses = New-Object -TypeName Microsoft.Open.AzureAD.Model.AssignedLicenses
$AssignedLicenses.AddLicenses = $License
$AssignedLicenses.RemoveLicenses = @()

$userList | % { Set-AzureADUserLicense -ObjectId $_.ObjectId -AssignedLicenses $AssignedLicenses}

#export to CSV
if (!$createdAccountCSVExportFullPath) {
    $createdAccountCSVExportFullPath = "$pwd\ExportMdpUsers$($accountSku.AccountName).csv"
}
$userList | % { New-Object -Type PSObject -Property @{Tenant = $tenantDomain; Login = $_.UserPrincipalName; Password = "3Rv0y1q39!$("{0:D3}" -f $_.GivenName)"} }| Export-Csv -Path $createdAccountCSVExportFullPath -NoTypeInformation -Delimiter ";"