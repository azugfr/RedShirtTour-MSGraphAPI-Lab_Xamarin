<#
.SYNOPSIS
    Using  Azure Active Directory PowerShell for Graph module, send invitation to external 
    user and add it to an Azure AD group
.DESCRIPTION
    Done for Azure Red Shirt Tour Paris 2018
.LINK
     https://www.adamfowlerit.com/2017/03/azure-ad-b2b-powershell-invites/
#>
param(
    [string]$TargetEmail,
    [string]$GroupName)

begin {
    #Connect to service
    $UserCredential = Get-Credential
    Connect-AzureAD -Credential $UserCredential >>$null
}

process {
    #get tenant info
    $group = get-azureadgroup -SearchString $GroupName | Where-Object {$_.dirsyncenabled -eq $null}

    if ($group.count -ne 1) {Write-Output "Not exactly one group found"; break}
    $TargetUrl = "https://outlook.office365.com/owa/$($group.Mail)/groupsubscription.ashx?source=WelcomeEmail&action=files"

    $InvitationResult = New-AzureADMSInvitation -InvitedUserEmailAddress $TargetEmail -InvitedUserDisplayName $TargetEmail -InviteRedirectUrl $TargetUrl -SendInvitationMessage $true

    #add the new user to your Security Group
    $userid = $InvitationResult.InvitedUser.Id
    Add-AzureADGroupMember -objectid $group.objectid -RefObjectId $userid
}

end {
    Disconnect-AzureAD
}