<#
.SYNOPSIS
    After tenant has been created and admin account manually set up, 
    using Microsoft Active Directory Module for Windows Powershell, launch this script.
    Login/password of tenant admin will be prompted.
    Export of accounts password will be stored in a CSV file 
.DESCRIPTION
    Done for Azure Red Shirt Tour Paris 2018
.LINK
     https://docs.microsoft.com/fr-fr/office365/enterprise/powershell/connect-to-office-365-powershell
#>
param(
    [string]$createdAccountCSVExportFullPath)

#Connect to service
$UserCredential = Get-Credential
Connect-MsolService -Credential $UserCredential 

#get tenant info
$accountSku = Get-MsolAccountSku

#create users and attrib licence
$userList = 1..21 | %{"{0:D3}" -f $_}  | New-MsolUser -DisplayName "Attendee $_" -FirstName "Test $_" -LastName "Test" -UserPrincipalName "test$_@$($accountSku.AccountName).onmicrosoft.com" -UsageLocation FR
$userList | %{ Set-MsolUserLicense -UserPrincipalName $_.UserPrincipalName -AddLicenses $accountSku.AccountSkuId}

#export to CSV
if (!$createdAccountCSVExportFullPath) {
    $createdAccountCSVExportFullPath = "$pwd\ExportMdpUsers$($accountSku.AccountName).csv"
}
$userList | %{ New-Object -Type PSObject -Property @{Tenant = $accountSku.AccountName; Login = $_.UserPrincipalName; Password = $_.Password} }| Export-Csv -Path $createdAccountCSVExportFullPath -NoTypeInformation -Delimiter ";"